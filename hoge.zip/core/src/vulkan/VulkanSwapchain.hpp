﻿#pragma once

#include <vulkan/vulkan.h>
#include <vector>
#include <memory>
#include "rhi/rhicommon.hpp" // SemaphoreHandle用
#include "rhi/RHIconfig.hpp" // SwapchainConfig用
#include "vulkan/VulkanImage.hpp"
#include "rhi/Swapchain.hpp" // rhi::Swapchain用

namespace core{
    class Window;
}

namespace rhi::vk {

    // 前方宣言
    class VulkanDevice;

    class VulkanSwapchain : public rhi::Swapchain {
    public:
        VulkanSwapchain(VulkanDevice& device, VkSurfaceKHR surface, const SwapchainConfig& config, const core::Window& window);
        ~VulkanSwapchain();

        // コピー・ムーブ禁止
        VulkanSwapchain(const VulkanSwapchain&) = delete;
        VulkanSwapchain& operator=(const VulkanSwapchain&) = delete;

        // リサイズ時に呼ばれる再構築メソッド
        void recreate(uint32_t width, uint32_t height);

        // 次の描画用画像を取得する。再構築が必要な場合(リサイズ時等)は false を返す
        bool acquireNextImage() override;
        // 描画結果を画面に表示する。再構築が必要な場合は false を返す
        bool present() override;

        // ゲッター群
        rhi::Image* getCurrentImage() const { return m_images[m_currentImageIndex].get(); }
        // rhi::Format getFormat() const { return static_cast<rhi::Format>(m_format); }
        VkExtent2D getExtent() const { return m_extent; }
        uint32_t getImageCount() const { return static_cast<uint32_t>(m_images.size()); }
        uint32_t getWidth() const { return m_extent.width; }
        uint32_t getHeight() const { return m_extent.height; }

        SemaphoreHandle getCurrentAcquireSemaphore() const {
            return reinterpret_cast<SemaphoreHandle>(m_currentAcquireSemaphore);
        }
        SemaphoreHandle getCurrentPresentSemaphore() const {
            return reinterpret_cast<SemaphoreHandle>(m_currentPresentSemaphore);
        }

        bool isEnableForCompute() override {return m_config.enableComputePresent;}

    private:
        void create(uint32_t width, uint32_t height);
        void cleanup();
        
        // スワップチェーンの最適設定を選択するヘルパー
        VkSurfaceFormatKHR chooseSwapSurfaceFormat(const std::vector<VkSurfaceFormatKHR>& availableFormats);
        VkPresentModeKHR chooseSwapPresentMode(const std::vector<VkPresentModeKHR>& availablePresentModes);
        VkExtent2D chooseSwapExtent(const VkSurfaceCapabilitiesKHR& capabilities, uint32_t width, uint32_t height);


    private:
        VulkanDevice& m_device;
        const core::Window& m_window; // サイズ取得のため
        SwapchainConfig m_config;

        VkSurfaceKHR m_surface = VK_NULL_HANDLE;
        VkSwapchainKHR m_swapchain = VK_NULL_HANDLE;
        VkFormat m_format;
        VkExtent2D m_extent;
        VkSemaphore m_currentAcquireSemaphore = VK_NULL_HANDLE;
        VkSemaphore m_currentPresentSemaphore = VK_NULL_HANDLE;
        std::vector<VkSemaphore> m_acquireSemaphores;
        std::vector<VkSemaphore> m_presentSemaphores;
        VkQueue m_presentQueue; // Present用のキュー（通常はGraphicsと同じ）

        std::vector<VkImage> m_vkImages;
        std::vector<std::unique_ptr<rhi::Image>> m_images; // RenderGraph等で扱うためのラッパー
        uint32_t m_currentImageIndex = 0;
    };

} // namespace rhi